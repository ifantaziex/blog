<?php
ini_set( 'display_errors', 1 );
error_reporting(E_ALL);

require_once (dirname(__FILE__).'/nodb-config.php');
require_once (dirname(__FILE__).'/nodb-includes/nodb-core.php');
if(!file_exists(THEME_DIR.'/functions.php')){
  echo "no theme defined";
  echo "<br>".(THEME_DIR.'/functions.php');
  exit(0);
}
require_once (THEME_DIR.'/functions.php');

$req = strtolower($_SERVER['REQUEST_URI']) ;
header('Content-type: text/html; charset=utf-8');
$page = '';
if(preg_match("/(^\/([A-Za-z-0-9]+)?(\?)?(.*)?$)/",$req,$pages))
{
   $rawpage = NODB_CONTENT.$pages['1'];
   $page = preg_replace("/\?(.*)?/i","",$rawpage);
   $page = $page.'.php';
   nodb::$canonical = $_SERVER['REQUEST_URI'];
}
# redirect index.php?popo
if (preg_match("/^\/index\.php(\?.*)?/",$req)){
  $newReq = str_replace('index.php','',$req);
  header("HTTP/1.1 301 Moved Permanently");
  header("Location: $newReq");
  exit(0);
}
# redirect berakhiran /
elseif (preg_match("/^\/.*\/$/",$req)){
  $newReq = preg_replace('/\/$/','',$req);
  header("HTTP/1.1 301 Moved Permanently");
  header("Location: $newReq");
  exit(0);
}
elseif (preg_match("/^\/(\?.*)?$/",$req)){
  require_once (NODB_CONTENT.'/index.php');
  require_once (THEME_DIR.'/index.php');
  exit(0);
}

else{
  if(file_exists($page)){
    //header("HTTP/1.1 200 OK");
    nodb::$canonical[0] = $_SERVER['REQUEST_URI'];
    require_once ($page);
    require_once (THEME_DIR.'/index.php');
}
  else {
    header("HTTP/1.1 404 Not Found");
    require_once(THEME_DIR.'/404.php');
    exit(0);
  }
}

?>