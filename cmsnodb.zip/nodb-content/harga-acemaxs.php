nodb::$title = 'Harga Ace Maxs';
nodb::$meta[0] = '<meta name="description" content="Harga Ace Maxs Retail distributor discount bulan ini">';
nodb::$content = <<<HTML

<p> </p>
<table>
<tbody>
<tr>
<td>Pembelian</td>
<td>Harga Retail </td>
<td>Discount</td>
<td>Ongkos kirim </td>
<td>Harga Net </td>
</tr>
<tr>
<td>
1 Botol
</td>
<td>
Rp.240.000
</td>
<td>
8211
</td>
<td>
Tarif JNE
</td>
<td>
Rp.240.000
</td>
</tr>
<tr>
<td>
2 Botol
</td>
<td>
Rp.480.000
</td>
<td>
Rp.5.000
</td>
<td>
Tarif JNE
</td>
<td>
Rp.475.000
</td>
</tr>
<tr>
<td>
3 Botol
</td>
<td>
Rp.720.000
</td>
<td>
Rp.15.000
</td>
<td>
Tarif JNE
</td>
<td>
Rp.705.000
</td>
</tr>
<tr>
<td>
6 Botol
</td>
<td>
Rp.1.440.000
</td>
<td>
Rp.115.000
</td>
<td>
Tarif JNE
</td>
<td>
Rp.1.325.000
</td>
</tr>
</tbody>
</table>

HTML;