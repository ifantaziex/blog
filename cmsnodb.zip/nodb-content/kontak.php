nodb::$title = 'Kontak Berobat.Net';
nodb::$meta[0] = '<meta name="description" content="Beli obat herbal terpercaya">';
nodb::$content = <<<HTML

<p> </p>
<p>Alamat Kami : Jl.Cikunteun Indah no.35 Kelurahan Sambong Jaya</p>
<p>Kec.Mangkubumi 46181 Kota Tasikmalaya Jawa Barat</p>
<table>
<tbody>
<tr>
<td>HP</td>
<td>: 085318732223</td>
</tr>
<tr>
<td>HP</td>
<td>: 085318732223</td>
</tr>
<tr>
<td>Kantor</td>
<td>: 0265 - 339207 </td>
</tr>
<tr>
<td>BBM</td>
<td>:529039F7</td>
</tr>
</tbody>
</table>
<p><br /> </p>

HTML;