<?php
nodb::$title = 'Obat Gondok Terpercaya Tanpa Efek Samping 100% Halal';
nodb::$meta[0] = '<meta name="description" content="Obat gondok tanpa efek samping, barang sampai baru bayar, gondok kronis sembuh menggunakan obat ini.">';
nodb::$content = <<<HTML

<p style="text-align: justify;"><strong>Anda memiliki penyakit gondok..?</strong> jangan khawatir ada obatnya, ACE MAXS obat gondok herbal yang telah terbukti mengobati penyakit gondok tanpa operasi, Ace Maxs obat gondok yang memiliki legalitas jelas terdaftar di POM dengan Nomor registrasi : POM TR. 142 680 331 Terbit Tanggal 15/09/2014. Dan lulus laboratorium kesehatan.<br /><br />Terbukti banyak yang sembuh dengan mengobati gondok menggunakan obat herbal Ace Maxs, Obat gondok ini aman dikonsumsi untuk anak anak usia 6 tahun dan dewasa tanpa efek samping. <br /><br />Kami BEROBAT.NET penjual terpercaya, <em><strong>belanja kepada kami bisa kirim barang dulu baru bayar setelah barang sampai</strong></em>. Untuk pemesanan cukup ketikan di hape anda format ini "RZ-ACM" kirim ke "085 318 732 223"<br /><br /><strong><em>Harga Ace Maxs</em></strong></p>

HTML;

?>