<?php
nodb::$title = 'BEROBAT.NET';
nodb::$meta[0] = '<meta name="description" content="berobat.net portal jual obat herbal terpercaya, obat gondok, obat jantung, obat kanker, asam urat, darah tinggi, dan obat maag kronis">';
nodb::$content = <<<HTML

<p style="text-align: justify;">BEROBAT.NET Jual berbagai obat herbal memiliki ijin resmi lulus BPOM dan Halal, Berobat.Net merupakan tempat membeli obat herbal terpercaya mengedepankan kejujuran, barang sampai baru bayar, kami percaya kepada anda, Obat yang kami jualpn sudah terpercaya dari ijin ijinnya yang resmi dan lulus standar badan kesehatan. Adapun obat yang kami jual ada 2 Jenis Yaitu Ace Maxs yang sudah terpercaya mengobati berbagai penyakit. Testimoni sukarela dari orang orang yang syriat menggunakan obat dari kami mereka sembuh. Dari mulai obat jantung, obat ggondok, obat asma, obat asam urat, obat maag kronis sembuh total tanpa ketergantungan dan tanpa menjalani operasi. </p>
<p style="text-align: justify;">Tidak hanya kata kata yang bisa berobat.net sampaikan tapi data nyata juga kami suguhkan untuk melengkapi pernyataan kami, dibawah ini anda bisa melihat ijin ijin kami resmi.</p>
<p style="text-align: justify;"><img src="E:\DATA WEB\nodb-content\images\registrasi-acemaxs.jpg" alt="Ace-Maxs-IRT" /></p>

HTML;

?>