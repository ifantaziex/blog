<?php
function loadFile($p) {
  try {
    require_once (THEME_DIR.'/'.$p);
  }
  catch (Exception $ex) {
    echo "eww";
  }
}

function loadContent($p) {
  try {
    require_once (NODB_CONTENT.'/'.$p);
  }
  catch (Exception $ex) {
    throw $ex;
  }
}

function loadText($t, $noecho = null) {
  if(empty ($t))
    return false;
  foreach($t as $text) {
    if(!empty ($noecho)) {
      return $text."\n";
    }
    else{
      echo $text."\n";
    }
  }
}

function cleanQuery($s) {
  $query = strtolower(preg_replace('/[\s\'\"\~\!\#\$\%\^\&\*\(\)\_\=\+\/\?\>\<\@\\\]+/', '-', trim($s)));
  return rawurlencode(trim($query, '-'));
}

class noDB {
  public static $title = "";
  public static $title2 = "";
  public static $content = "";
  public static $meta = array();
  public static $script = array();
  public static $css = array();
  public static $custom = array();
  public static $canonical = "";
  public static $Breadcrumb = "";
  public static $jsBefore = array();
  public static $jsAfter = array();
  public static $notFound = false;
}

function alt_title(){
  if(!empty(nodb::$title2)){
    echo nodb::$title2;
  }
  else{
    echo nodb::$title;
  }
}
?>