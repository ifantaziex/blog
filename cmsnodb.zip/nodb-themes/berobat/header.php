<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title><?php echo nodb::$title ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link href="<?php echo THEME_URL; ?>/css/style.css" rel="stylesheet" type="text/css">
  <link href="<?php echo THEME_URL; ?>/css/media.css" rel="stylesheet" type="text/css">
  <?php echo loadText(nodb::$meta); ?>

</head>

<body class="single single-post">
  <div id="wrap">
    <div id="header">
      <div class="logo">noDBcms.com</div>
    </div>
    <div id="nav">
      <ul>
        <li><a href="/" class="linkhome">BEROBAT.NET</a></li>
        <li><a href="#kontak">KONTAK</a></li>
      </ul>
    </div>
    <div id="breadchumb">

    </div>
    <div class="adsheader">
    </div>
    <div style="clear: both"></div>
    <div id="container">
      <div id="contents">
        <div class="post">