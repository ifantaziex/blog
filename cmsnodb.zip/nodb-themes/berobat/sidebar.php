      <div id="sidebar">

        <div class="box">
          <h3>Artikel Terbaru</h3>
          <ul>
            <li><a href="/satria-fu">Harga Motor Suzuki Satria Fu Terbaru 2015</a></li>
            <li><a href="/yamaha-vixion">Harga Motor Yamaha Vixion Terbaru 2015</a></li>
          </ul>
        </div>

        <div class="box">
          <h3>Berharga Lainnya</h3>
          <ul>
            <li><a href="/satria-fu">Harga Motor Suzuki Satria Fu Terbaru 2015</a></li>
            <li><a href="/yamaha-vixion">Harga Motor Yamaha Vixion Terbaru 2015</a></li>
          </ul>
        </div>

      </div>
      <div style="clear: both"></div>
    </div>