<?php
nodb::$title = 'Halaman Tidak di temukan';
nodb::$content = <<<HTML

<p>Halaman yang anda minta Tidak di temukan</p>

HTML;

loadFile("header.php");
?>
          <div class="post-title">
            <h1><?php echo nodb::$title ?></h1>
          </div>
          <div class="adstop">
            <!-- <div class="ads">Advertisement</div> -->
          </div>

          <?php echo nodb::$content ?>

          <div class="adsbottom">
            <!-- <div class="ads">Advertisement</div> --></div>
          <div style="clear: both"></div>

        </div>
      </div>

<?php
loadFile("sidebar.php");
loadFile("footer.php");
?>