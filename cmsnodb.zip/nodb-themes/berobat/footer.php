    <footer id="footer">
      &copy; 2015 / <a href="#privacy-policy">Privacy Policy</a> / <a href="#disclaimer">Disclaimer</a> / <a href="#contact">Contact</a>

    </footer>
  </div>

</body>

</html>