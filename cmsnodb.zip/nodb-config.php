<?php
define('NODB_SITE', 'http://berobat.net');
define('THEME_NAME', 'berobat');
define('THEME_DIR', dirname(__FILE__).'/nodb-themes/'.THEME_NAME);
define('THEME_URL', NODB_SITE.'/nodb-themes/'.THEME_NAME);
define('NODB_CONTENT', dirname(__FILE__).'/nodb-content');
define('ABSPATH', dirname(__FILE__));
?>